##### Hj�lp! Felmeddelande om vc-redist-dll-n�got!
      Bara lugn, du beh�ver ladda ner VC++ 2012 Redistributable fr�n Microsoft:
      http://www.microsoft.com/en-US/download/details.aspx?id=30679
      
      Om den inte finns p� Microsofts sida l�ngre finns den med i denna .zip som vcredist_x64.exe

            
##### Svart sk�rm, konstiga f�rger, krasch etc.
      Om spelet inte skulle fungera kan det bero p� att du f�rs�ker k�ra det p� en riktigt gammal dator,
      eller ocks� har du inte laddat ner senaste drivrutinen till ditt grafikkort. Kolla t.ex. h�r:
      http://www.nvidia.com/Download/index.aspx

      Det kan ocks� vara s� enkelt som att du beh�ver installera VC++ 2012 Redistributable, se ovan.